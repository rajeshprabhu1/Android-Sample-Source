<?php

/**
 * @author Ravi Tamada
 * @link URL Tutorial link
 */
class Firebase {

    // sending push message to single user by firebase reg id
    public function send($message) {
        $fields = array(
            'to' => 'eL-B3QuLdgU:APA91bEnZvQPHLKG4hc0W8DcO7pa9m0JlWxaOOTXXds87tfqnnM8YcuNiusoCAXkOnf1pYJ2ZsL8eV0cbUimv5FFyhRhh8doDYLKhSO8cRWPM-sac-HU9d7ox1irPkY-tZTy-1neHcKG',
            'data' => $message,
        );
        return $this->sendPushNotification($fields);
    }

  
    // function makes curl request to firebase servers
    private function sendPushNotification($fields) {
        
        require_once __DIR__ . '/config.php';

        // Set POST variables
        $url = 'https://fcm.googleapis.com/fcm/send';
$server_key = 'AIzaSyCJxa_rcu4vgrm-Q8i2iPYxbfCuw1lYFXU';
        $headers = array(
            'Authorization: key='.$server_key,
            'Content-Type: application/json'
        );
        // Open connection
        $ch = curl_init();

        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        // Execute post
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }

        // Close connection
        curl_close($ch);

		//echo $result;

        return $result;
    }
}

?>