<?php


// Firebase API Key
define('FIREBASE_API_KEY', 'AIzaSyDr-ijf24MGzjvYd_BZludG0LvVu2WAOmM');
