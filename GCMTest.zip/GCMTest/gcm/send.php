<?php

//Checking http request we are using post here 
if($_SERVER['REQUEST_METHOD']=='POST'){
	
	//Getting api key 
	$api_key = 'AIzaSyCJxa_rcu4vgrm-Q8i2iPYxbfCuw1lYFXU';	
	
	//Getting registration token we have to make it as array 
	$reg_token = $_POST['regtoken'];
//	echo $_POST['regtoken'];
	//Getting the message 
	$message = $_POST['message'];
	
	//Creating a message array 
	$msg = array
	(
		'message' 	=> $message,
		 
	);
	
	//Creating a new array fileds and adding the msg array and registration token array here 
	$fields = array
	(
		'to' => $reg_token,
		'data'			=> $msg
	);
	
	//Adding the api key in one more array header 
	$headers = array
	(
		'Authorization: key=' . $api_key,
		'Content-Type: application/json'
	); 
	
	//Using curl to perform http request 
	
	 

	
	
	$ch = curl_init();
	curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
	curl_setopt( $ch,CURLOPT_POST, true);
	curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers);
	curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode($fields) );
	
	//Getting the result 
	$result = curl_exec($ch);
	if ($result === FALSE) {
		
            die('Curl failed: ' . curl_error($ch));
			
        } 
		
		
    echo $result;
	//Decoding json from result 
	$res = json_decode($result);
	
	
	
$flag = $res->success;
	if($flag == 1){
		
		echo 'success';
		//Redirecting back to our form with a request success 
		//header('Location: index.php?success');
	}else{
		
		echo 'failure';
		//Redirecting back to our form with a request failure 
		//header('Location: index.php?failure');
	}
	curl_close( $ch );
	//Getting value from success 
	 
}