package com.rakesh.myapplication;

public class Utility {

	static final String SERVER_URL = null;  //Need to fill it here.
	static final String SENDER_ID = "663465162444";//"114172487736";
	
	
}
